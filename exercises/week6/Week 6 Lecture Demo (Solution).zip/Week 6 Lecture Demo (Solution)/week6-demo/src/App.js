import { BrowserRouter, Routes, Route } from "react-router-dom";

import styles from "./css/styles.css";
// Same as above, and React Web will automatically link it

import Header from "./components/Header.js";
import Footer from "./components/Footer.js";
import LatestPosts from "./components/LatestPosts.js";
import AboutUs from "./components/AboutUs.js";
import ContactUs from "./components/ContactUs.js";

function App() {
	return (
		<BrowserRouter>
			<Header />
			<main>
				<Routes>
					<Route path="/" element={<LatestPosts />} />
					<Route path="/post/:id" element={<LatestPosts />} />
					<Route path="about-us" element={<AboutUs />} />
					<Route path="contact-us" element={<ContactUs />} />
				</Routes>
			</main>
			<Footer />
		</BrowserRouter>
	);
}

export default App;