function Footer() {
	return (
		<footer className="page-footer">
			&copy; Web/Mobile Programming (COMP2140)
		</footer>
	);
}

export default Footer;