import useDocumentTitle from "../useDocumentTitle.js";

function ContactUs() {
	useDocumentTitle("Contact Us");
	return (
		<>
			<h2>Contact Us</h2>
			<article>
				<form>
					<label>
						Name: 
						<input type="text" name="name" />
					</label>
					<label>
						Email: 
						<input type="email" name="email" />
					</label>
					<label>
						Comment: 
						<textarea name="comment"></textarea>
					</label>
					<button type="submit">Submit</button>
				</form>
			</article>
		</>
	);
}

export default ContactUs;