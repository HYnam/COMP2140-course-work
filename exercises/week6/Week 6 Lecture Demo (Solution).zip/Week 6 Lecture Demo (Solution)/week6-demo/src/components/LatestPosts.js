import { useParams, Link } from "react-router-dom";
import useDocumentTitle from "../useDocumentTitle.js";

function Post(props) {
	return (
		<article>
			<h3>
				<Link to={`/post/${props.postID}`}>{props.postTitle}</Link>
			</h3>
			<p>
				{props.postContent}
			</p>
		</article>
	);
}

function LatestPosts() {

	const latestPosts = [
		{
			postID: 11,
			postTitle: "Gold Coast Line to Shut Down",
			postTeaser: "Due to the increasing popularity of the motor car, and political interests in road transport, the...",
			postBody: "Due to the increasing popularity of the motor car, and political interests in road transport, the Tweed Heads branch closed in 1961 and the line from Beenleigh to Southport closed in 1964.",
		},
		{
			postID: 12,
			postTitle: "Cat Rides the Airport Line",
			postTeaser: "A cat has been seen riding the Airport line. Nobody knows if the cat got off a plane at the Domestic terminal or the International terminal, but...",
			postBody: "A cat has been seen riding the Airport line. Nobody knows if the cat got off a plane at the Domestic terminal or the International terminal, but that's silly because it's a cat.",
		},
	];

	let id = useParams().id;
	let [post] = latestPosts.filter(latestPost => latestPost.postID == id);

	if(post === undefined) {
		// Show "Latest Posts" page
		useDocumentTitle("Latest Posts");
		return (
			<>
				<h2>Latest Posts</h2>
				<section className="posts">
					{latestPosts.map(latestPost => <Post key={latestPost.postID} postContent={latestPost.postTeaser} {...latestPost} />)}
				</section>
			</>
		);
	}
	
	else {
		// Show a specific post
		useDocumentTitle(post.postTitle);
		return (
			<Post key={post.postID} postContent={post.postBody} {...post} />
		);
	}

}

export default LatestPosts;