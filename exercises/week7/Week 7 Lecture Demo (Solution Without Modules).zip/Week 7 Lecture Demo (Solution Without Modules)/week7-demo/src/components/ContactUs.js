import useDocumentTitle from "../useDocumentTitle.js";

function ContactUs({ formSubmissions, setFormSubmissions }) {

	function handleSubmit(event) {
		console.log("<ContactUs> component event called");
		event.preventDefault();
		const formName = event.target.elements.name.value;
		const formEmail = event.target.elements.email.value;
		const formComment = event.target.elements.comment.value;
		if(formName && formEmail && formComment) {
			setFormSubmissions([...formSubmissions, {
				name: formName,
				email: formEmail,
				comment: formComment,
			}]);
		}
	}

	useDocumentTitle("Contact Us");
	console.log("<ContactUs> component rendered");
	
	return (
		<>
			<h2>Contact Us</h2>
			<article>
				<form onSubmit={handleSubmit}>
					<label>
						Name: 
						<input type="text" name="name" />
					</label>
					<label>
						Email: 
						<input type="email" name="email" />
					</label>
					<label>
						Comment: 
						<textarea name="comment"></textarea>
					</label>
					<button type="submit">Submit</button>
				</form>
			</article>
			<h2>Previous Form Submissions</h2>
			<table border="1">
				<thead>
					<tr>
						<th>Name</th>
						<th>Email</th>
						<th>Comment</th>
					</tr>
				</thead>
				<tbody>
					{formSubmissions.map((formSubmission, index) => 
						<tr key={index}>
							<td>{formSubmission.name}</td>
							<td>{formSubmission.email}</td>
							<td>{formSubmission.comment}</td>
						</tr>
					)}
				</tbody>
			</table>
		</>
	);
}

export default ContactUs;