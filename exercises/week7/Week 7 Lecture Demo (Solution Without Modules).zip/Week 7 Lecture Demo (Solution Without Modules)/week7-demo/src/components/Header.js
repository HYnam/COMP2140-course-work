import { Link, NavLink } from "react-router-dom";

function Header() {
	return (
		<header className="page-header">
			<h1>
				<Link to="/">QLD Train Rumours</Link>
			</h1>
			<nav className="main-menu">
				<NavLink to="/">Latest Posts</NavLink>
				<NavLink to="/about-us">About Us</NavLink>
				<NavLink to="/contact-us">Contact Us</NavLink>
			</nav>
		</header>
	);
}

export default Header;