import useDocumentTitle from "../useDocumentTitle.js";

import aboutImage from "../images/about.jpg";
// Tells webpack to include the image in the bundle

function AboutUs({count, setCount }) {
	
	useDocumentTitle("About Us");
	console.log("<AboutUs> component rendered");
	return (
		<>
			<h2>About Us</h2>
			<article>
				<p>
					<strong>QLD Train Rumours</strong> is where you can get the latest news about train lines, stock movements etc in Queensland, Australia.
				</p>
				<p>
					<img src={aboutImage} alt="A Queensland Rail train at a station" />
				</p>
				<p>You clicked the button {count} times.</p>
				<button onClick={() => setCount(count + 1)}>
					Click me
				</button>
			</article>
		</>
	);

}

export default AboutUs;