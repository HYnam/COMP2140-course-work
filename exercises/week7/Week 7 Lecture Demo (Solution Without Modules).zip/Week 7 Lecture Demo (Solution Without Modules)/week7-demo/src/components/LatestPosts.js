import { useParams, Link } from "react-router-dom";
import useDocumentTitle from "../useDocumentTitle.js";

function Post(props) {
	console.log("<Post> component rendered");
	return (
		<article>
			<h3>
				<Link to={`/post/${props.postID}`}>{props.postTitle}</Link>
			</h3>
			<p>
				{props.postContent}
			</p>
		</article>
	);
}

function LatestPosts({ latestPosts }) {

	let id = useParams().id;
	let [post] = latestPosts.filter(latestPost => latestPost.postID == id);

	if(post === undefined) {
		// Show "Latest Posts" page
		useDocumentTitle("Latest Posts");
		console.log("<LatestPosts> component rendered to posts listing");
		return (
			<>
				<h2>Latest Posts</h2>
				<section className="posts">
					{latestPosts.map(latestPost => <Post key={latestPost.postID} postContent={latestPost.postTeaser} {...latestPost} />)}
				</section>
			</>
		);
	}
	
	else {
		// Show a specific post
		useDocumentTitle(post.postTitle);
		console.log("<LatestPosts> component rendered to specific post");
		return (
			<Post key={post.postID} postContent={post.postBody} {...post} />
		);
	}

}

export default LatestPosts;