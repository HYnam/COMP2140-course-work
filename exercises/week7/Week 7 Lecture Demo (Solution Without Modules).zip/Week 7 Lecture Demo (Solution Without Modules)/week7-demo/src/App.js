import { useState, useEffect } from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";

import styles from "./css/styles.css";
// Same as above, and React Web will automatically link it

import Header from "./components/Header.js";
import Footer from "./components/Footer.js";
import LatestPosts from "./components/LatestPosts.js";
import AboutUs from "./components/AboutUs.js";
import ContactUs from "./components/ContactUs.js";

function App() {

	const [count, setCount] = useState(0);

	const initialLatestPosts = [];
	const [ latestPosts, setLatestPosts ] = useState(initialLatestPosts);

	useEffect(() => {
		console.log("<App> component effect hook called");
		getLatestPosts();
	}, []);

	async function getLatestPosts() {
        const response = await fetch("http://wmp.interaction.courses/train-news");
        const json = await response.json();
		console.log(json);
        setLatestPosts(json);
    }

	const initialFormSubmissions = [];
	const [ formSubmissions, setFormSubmissions ] = useState(initialFormSubmissions);

	return (
		<BrowserRouter>
			<Header />
			<main>
				<Routes>
					<Route path="/" element={<LatestPosts latestPosts={latestPosts} />} />
					<Route path="post/:id" element={<LatestPosts latestPosts={latestPosts} />} />
					<Route path="about-us" element={<AboutUs count={count} setCount={setCount} />} />
					<Route path="contact-us" element={<ContactUs formSubmissions={formSubmissions} setFormSubmissions={setFormSubmissions} />} />
				</Routes>
			</main>
			<Footer />
		</BrowserRouter>
	);

}

export default App;